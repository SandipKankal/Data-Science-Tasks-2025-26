# car_classification.py
# UCI Car Evaluation — RandomForest + SVM (with One-Hot encoding)
import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report

RANDOM_STATE = 42
CSV_PATH = "dataset/car.data"   # <- your file

# Column names from car.names
COLS = ["buying", "maint", "doors", "persons", "lug_boot", "safety", "class"]

# ---------------------------
# 1) Load data
# ---------------------------
df = pd.read_csv(CSV_PATH, header=None, names=COLS)
print(f"✅ Loaded: {df.shape}")
print(df.head())

# ---------------------------
# 2) Split features/target
# ---------------------------
X = df.drop(columns=["class"])
y = df["class"]                     # classes: unacc, acc, good, vgood

# (All features are categorical)
cat_features = list(X.columns)

# OneHotEncoder: support both old/new sklearn versions
try:
    ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
except TypeError:
    ohe = OneHotEncoder(handle_unknown="ignore", sparse=False)

preprocess = ColumnTransformer(
    transformers=[("cat", ohe, cat_features)],
    remainder="drop"
)

# ---------------------------
# 3) Train/test split
# ---------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE
)

# ---------------------------
# Helper: evaluation
# ---------------------------
def evaluate(name, model):
    y_pred = model.predict(X_test)
    acc  = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, average="weighted", zero_division=0)
    rec  = recall_score(y_test, y_pred, average="weighted", zero_division=0)
    f1   = f1_score(y_test, y_pred, average="weighted", zero_division=0)

    print(f"\n🔹 {name}")
    print(f"Accuracy : {acc:.3f}")
    print(f"Precision: {prec:.3f}")
    print(f"Recall   : {rec:.3f}")
    print(f"F1 Score : {f1:.3f}")
    print("\nClassification Report:\n", classification_report(y_test, y_pred, digits=3))

# ---------------------------
# 4) Random Forest (tuned)
# ---------------------------
rf_pipe = Pipeline([
    ("prep", preprocess),
    ("model", RandomForestClassifier(random_state=RANDOM_STATE, class_weight=None))
])

rf_params = {
    "model__n_estimators": [100, 200],
    "model__max_depth": [None, 10, 20],
    "model__min_samples_split": [2, 5],
    "model__min_samples_leaf": [1, 2]
}
rf_grid = GridSearchCV(rf_pipe, rf_params, cv=3, scoring="accuracy", n_jobs=-1)
rf_grid.fit(X_train, y_train)
rf_best = rf_grid.best_estimator_
print("\n✅ Best RF Params:", rf_grid.best_params_)

evaluate("Random Forest (Tuned)", rf_best)

# ---------------------------
# 5) SVM (tuned, RBF kernel)
# ---------------------------
svm_pipe = Pipeline([
    ("prep", preprocess),
    ("model", SVC(kernel="rbf", probability=False, class_weight=None, random_state=RANDOM_STATE))
])

svm_params = {
    "model__C": [0.5, 1, 2],
    "model__gamma": ["scale", "auto"]
}
svm_grid = GridSearchCV(svm_pipe, svm_params, cv=3, scoring="accuracy", n_jobs=-1)
svm_grid.fit(X_train, y_train)
svm_best = svm_grid.best_estimator_
print("\n✅ Best SVM Params:", svm_grid.best_params_)

evaluate("SVM (RBF, Tuned)", svm_best)

print("\n✅ Car Evaluation Classification Completed.")
