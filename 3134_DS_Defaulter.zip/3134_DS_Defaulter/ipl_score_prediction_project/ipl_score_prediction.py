# ipl_score_prediction.py
# Practical 12 - Predict the IPL Score using Linear Regression and Decision Tree

import warnings
warnings.filterwarnings("ignore")

# -------------------------------
# 1️⃣ Import Libraries
# -------------------------------
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.impute import SimpleImputer

# -------------------------------
# 2️⃣ Load Dataset
# -------------------------------
try:
    deliveries_df = pd.read_csv("dataset/deliveries.csv")
    matches_df = pd.read_csv("dataset/matches.csv")
    print("✅ Successfully loaded IPL datasets.")
except Exception as e:
    print(f"❌ Error loading dataset: {e}")
    exit()

print("\nDeliveries Data:", deliveries_df.shape)
print("Matches Data:", matches_df.shape)

# -------------------------------
# 3️⃣ Data Preparation & Feature Engineering
# -------------------------------
# Filter first innings data
df_1st_inning = deliveries_df[deliveries_df['inning'] == 1].copy()

# Compute cumulative score and wickets
df_1st_inning['Current_Score'] = df_1st_inning.groupby('match_id')['total_runs'].cumsum()
df_1st_inning['is_out'] = df_1st_inning['is_wicket'].apply(lambda x: 1 if x == 1 else 0)
df_1st_inning['Current_Wickets'] = df_1st_inning.groupby('match_id')['is_out'].cumsum()

# Final total score for each match
final_scores = df_1st_inning.groupby('match_id')['Current_Score'].max().reset_index()
final_scores.rename(columns={'Current_Score': 'Total_Target_Score'}, inplace=True)

# Merge target back
df_merged = pd.merge(df_1st_inning, final_scores, on='match_id')

# Filter only after 5th over (more realistic data)
df_model = df_merged[df_merged['over'] >= 5]

# Features and Target
X = df_model[['batting_team', 'bowling_team', 'Current_Score', 'Current_Wickets', 'over']]
y = df_model['Total_Target_Score']

# -------------------------------
# 4️⃣ Preprocessing
# -------------------------------
categorical_features = ['batting_team', 'bowling_team']
numerical_features = ['Current_Score', 'Current_Wickets', 'over']

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = OneHotEncoder(handle_unknown='ignore')

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ]
)

# -------------------------------
# 5️⃣ Train-Test Split
# -------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# -------------------------------
# 6️⃣ Train and Evaluate Models
# -------------------------------
models = {
    'Linear Regression': LinearRegression(),
    'Decision Tree Regressor': DecisionTreeRegressor(max_depth=10, random_state=42)
}

results = []

print("\n--- Training & Evaluating IPL Score Prediction Models ---")
for name, model in models.items():
    # Pipeline for each model
    pipeline = Pipeline(steps=[('preprocessor', preprocessor),
                               ('regressor', model)])
    pipeline.fit(X_train, y_train)

    # Predictions
    y_pred = pipeline.predict(X_test)

    # Evaluation Metrics
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    acc = r2 * 100

    results.append((name, mae, r2, acc))

    print(f"\n🔹 {name}")
    print(f"Mean Absolute Error (MAE): {mae:.2f} runs")
    print(f"R² Score: {r2:.3f}")
    print(f"Accuracy (approx): {acc:.2f}%")

# -------------------------------
# 7️⃣ Summary Table
# -------------------------------
print("\n📊 Final Model Comparison:")
df_results = pd.DataFrame(results, columns=['Model', 'MAE', 'R2_Score', 'Accuracy (%)'])
print(df_results.to_string(index=False))

print("\n✅ IPL Score Prediction Completed Successfully!")
