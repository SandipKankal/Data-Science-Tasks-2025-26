# crop_yield_prediction.py
import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# =====================================================
# 1️⃣ Load all datasets
# =====================================================
print("✅ Loading all CSV files...")

rainfall = pd.read_csv("dataset/rainfall.csv")
temperature = pd.read_csv("dataset/temp.csv")
pesticides = pd.read_csv("dataset/pesticides.csv")
yield_data = pd.read_csv("dataset/yield.csv")

# Convert all column names to lowercase for easy matching
for df in [rainfall, temperature, pesticides, yield_data]:
    df.columns = df.columns.str.lower()

# =====================================================
# 2️⃣ Merge all datasets safely
# =====================================================
print("\n🔄 Merging datasets...")

# Common lowercase keys often used
possible_keys = ["year", "state", "country", "district", "crop"]

# Find matching keys
merge_keys = [col for col in possible_keys if col in rainfall.columns and col in yield_data.columns]

merged = yield_data.copy()

for df in [rainfall, temperature, pesticides]:
    common = [c for c in merge_keys if c in df.columns]
    if common:
        merged = pd.merge(merged, df, on=common, how="left")
        print(f"✅ Merged on keys: {common}")
    else:
        print(f"⚠️ No common keys found for {list(df.columns)} — merging by row index instead.")
        merged = pd.concat([merged.reset_index(drop=True), df.reset_index(drop=True)], axis=1)

print(f"✅ Final merged dataset shape: {merged.shape}")
print(merged.head())

# =====================================================
# 3️⃣ Clean & prepare data
# =====================================================
merged = merged.dropna()  # remove missing rows

# Drop non-numeric columns if present
non_numeric = merged.select_dtypes(include=['object']).columns.tolist()
if non_numeric:
    print(f"\n⚠️ Dropping non-numeric columns: {non_numeric}")
    merged = merged.drop(columns=non_numeric)

# Identify target column
target_col = "yield" if "yield" in merged.columns else merged.columns[-1]
X = merged.drop(columns=[target_col])
y = merged[target_col]

# =====================================================
# 4️⃣ Feature Scaling
# =====================================================
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# =====================================================
# 5️⃣ Train/Test Split
# =====================================================
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

# =====================================================
# 6️⃣ Decision Tree Regressor (Tuned)
# =====================================================
print("\n🌳 Training Decision Tree Regressor...")

dt_params = {
    "max_depth": [4, 6, 8, 10, 12],
    "min_samples_split": [2, 5, 10],
    "min_samples_leaf": [1, 2, 4]
}

dt_grid = GridSearchCV(
    DecisionTreeRegressor(random_state=42),
    dt_params, cv=5, scoring="r2", n_jobs=-1
)
dt_grid.fit(X_train, y_train)
dt_best = dt_grid.best_estimator_

print("✅ Best Decision Tree Params:", dt_grid.best_params_)

y_pred_dt = dt_best.predict(X_test)

# =====================================================
# 7️⃣ Random Forest Regressor (Tuned)
# =====================================================
print("\n🌲 Training Random Forest Regressor...")

rf_params = {
    "n_estimators": [50, 100],
    "max_depth": [6, 8, 10, 12],
    "min_samples_split": [2, 5],
    "min_samples_leaf": [1, 2]
}

rf_grid = GridSearchCV(
    RandomForestRegressor(random_state=42),
    rf_params, cv=5, scoring="r2", n_jobs=-1
)
rf_grid.fit(X_train, y_train)
rf_best = rf_grid.best_estimator_

print("✅ Best Random Forest Params:", rf_grid.best_params_)

y_pred_rf = rf_best.predict(X_test)

# =====================================================
# 8️⃣ Evaluation Function
# =====================================================
def evaluate_regression(name, y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    print(f"\n🔹 Model: {name}")
    print(f"MAE  : {mae:.3f}")
    print(f"RMSE : {rmse:.3f}")
    print(f"R²   : {r2:.3f}")

evaluate_regression("Decision Tree (tuned)", y_test, y_pred_dt)
evaluate_regression("Random Forest (tuned)", y_test, y_pred_rf)

print("\n✅ Crop Yield Prediction Completed Successfully!")
