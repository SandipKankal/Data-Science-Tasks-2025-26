# fraud_detection_clean.py
# Decision Tree + Neural Network (MLP) with proper preprocessing for imbalance.
import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import RobustScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    classification_report, roc_auc_score
)
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
from imblearn.under_sampling import RandomUnderSampler

RANDOM_STATE = 42

# ---------------------------
# 1️⃣ Load data
# ---------------------------
df = pd.read_csv("dataset/creditcard.csv")
print("✅ Loaded:", df.shape)

# ---------------------------
# 2️⃣ Basic prep
# ---------------------------
y = df["Class"].astype(int)

# Scale only 'Time' and 'Amount'
scaler = RobustScaler()
df["Amount_Scaled"] = scaler.fit_transform(df[["Amount"]])
df["Time_Scaled"]   = scaler.fit_transform(df[["Time"]])
X = df.drop(columns=["Class", "Amount", "Time"])

# ---------------------------
# 3️⃣ Train/test split
# ---------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE
)

print("\nClass distribution (train) before resampling:")
print(y_train.value_counts())

# ---------------------------
# 4️⃣ Handle class imbalance
# ---------------------------
rus = RandomUnderSampler(random_state=RANDOM_STATE)
X_train_bal, y_train_bal = rus.fit_resample(X_train, y_train)

print("\nClass distribution (train) AFTER resampling:")
print(y_train_bal.value_counts())

# ---------------------------
# Helper: evaluation
# ---------------------------
def evaluate(name, y_true, y_pred, y_proba=None):
    acc  = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec  = recall_score(y_true, y_pred, zero_division=0)
    f1   = f1_score(y_true, y_pred, zero_division=0)
    print(f"\n🔹 Model: {name}")
    print(f"Accuracy : {acc:.3f}")
    print(f"Precision: {prec:.3f}")
    print(f"Recall   : {rec:.3f}")
    print(f"F1 Score : {f1:.3f}")
    if y_proba is not None:
        try:
            auc = roc_auc_score(y_true, y_proba)
            print(f"ROC-AUC  : {auc:.3f}")
        except Exception:
            pass
    print("\nClassification Report:\n", classification_report(y_true, y_pred, digits=3))

# ---------------------------
# 5️⃣ Decision Tree (tuned)
# ---------------------------
dt_params = {
    "criterion": ["gini", "entropy"],
    "max_depth": [4, 6, 8, 10, 12],
    "min_samples_split": [2, 10, 50],
    "min_samples_leaf": [1, 5, 20]
}
dt_grid = GridSearchCV(
    DecisionTreeClassifier(class_weight="balanced", random_state=RANDOM_STATE),
    dt_params, cv=5, scoring="f1", n_jobs=-1
)
dt_grid.fit(X_train_bal, y_train_bal)
dt_best = dt_grid.best_estimator_
print("\n✅ Decision Tree best params:", dt_grid.best_params_)

y_pred_dt = dt_best.predict(X_test)
y_proba_dt = dt_best.predict_proba(X_test)[:, 1] if hasattr(dt_best, "predict_proba") else None
evaluate("Decision Tree", y_test, y_pred_dt, y_proba_dt)

# ---------------------------
# 6️⃣ Neural Network (MLP)
# ---------------------------
mlp = MLPClassifier(
    hidden_layer_sizes=(64, 32),
    activation="relu",
    solver="adam",
    alpha=1e-4,
    learning_rate_init=1e-3,
    max_iter=200,
    early_stopping=True,
    n_iter_no_change=10,
    random_state=RANDOM_STATE
)
mlp.fit(X_train_bal, y_train_bal)

y_pred_mlp  = mlp.predict(X_test)
y_proba_mlp = mlp.predict_proba(X_test)[:, 1]
evaluate("Neural Net (MLP)", y_test, y_pred_mlp, y_proba_mlp)

print("\n✅ Done.")
