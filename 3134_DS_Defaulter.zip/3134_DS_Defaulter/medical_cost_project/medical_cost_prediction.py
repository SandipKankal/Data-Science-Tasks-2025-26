# medical_cost_prediction_optimized.py
import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

RANDOM_STATE = 42
CSV_PATH = "dataset/insurance.csv"

# ---------------------------
# 1️⃣ Load Data
# ---------------------------
df = pd.read_csv(CSV_PATH)
print(f"✅ Loaded dataset: {df.shape}")
print(df.head(3))

# ---------------------------
# 2️⃣ Split Features/Target
# ---------------------------
X = df.drop(columns=["charges"])
y = df["charges"].astype(float)

num_features = ["age", "bmi", "children"]
cat_features = ["sex", "smoker", "region"]

# ---------------------------
# 3️⃣ Preprocessing Pipeline
# ---------------------------
preprocessor = ColumnTransformer(
    transformers=[
        ("num", StandardScaler(), num_features),
        ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), cat_features)
    ]
)

# ---------------------------
# 4️⃣ Split Data
# ---------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE
)

# ---------------------------
# 🧮 Evaluation Helper
# ---------------------------
def evaluate_model(name, model, X_test, y_test):
    y_pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)
    print(f"\n🔹 {name}")
    print(f"Accuracy : {r2*100:.2f}%")
    print(f"R² Score : {r2:.3f}")
    print(f"MAE      : {mae:.2f}")
    print(f"RMSE     : {rmse:.2f}")
    return r2 * 100

# ---------------------------
# 5️⃣ Linear Regression (Baseline)
# ---------------------------
linreg_pipe = Pipeline([
    ("preprocess", preprocessor),
    ("model", LinearRegression())
])
linreg_pipe.fit(X_train, y_train)
acc_lr = evaluate_model("Linear Regression", linreg_pipe, X_test, y_test)

# ---------------------------
# 6️⃣ Decision Tree (Tuned, Efficient Grid)
# ---------------------------
dt_pipe = Pipeline([
    ("preprocess", preprocessor),
    ("model", DecisionTreeRegressor(random_state=RANDOM_STATE))
])

dt_params = {
    "model__max_depth": [4, 6, 8, 10],
    "model__min_samples_split": [2, 5, 10],
    "model__min_samples_leaf": [1, 2, 4],
}

dt_grid = GridSearchCV(dt_pipe, dt_params, cv=3, scoring="r2", n_jobs=-1)
dt_grid.fit(X_train, y_train)
dt_best = dt_grid.best_estimator_
print("\n✅ Best Decision Tree Params:", dt_grid.best_params_)
acc_dt = evaluate_model("Decision Tree (Tuned)", dt_best, X_test, y_test)

# ---------------------------
# 7️⃣ Random Forest (Best Overall)
# ---------------------------
rf_pipe = Pipeline([
    ("preprocess", preprocessor),
    ("model", RandomForestRegressor(random_state=RANDOM_STATE))
])

rf_params = {
    "model__n_estimators": [100, 150],
    "model__max_depth": [6, 8, 10],
    "model__min_samples_split": [2, 5],
    "model__min_samples_leaf": [1, 2]
}

rf_grid = GridSearchCV(rf_pipe, rf_params, cv=3, scoring="r2", n_jobs=-1)
rf_grid.fit(X_train, y_train)
rf_best = rf_grid.best_estimator_
print("\n✅ Best Random Forest Params:", rf_grid.best_params_)
acc_rf = evaluate_model("Random Forest (Tuned)", rf_best, X_test, y_test)

# ---------------------------
# 8️⃣ Comparison Summary
# ---------------------------
print("\n📊 Final Comparison:")
print(f"Linear Regression Accuracy : {acc_lr:.2f}%")
print(f"Decision Tree Accuracy     : {acc_dt:.2f}%")
print(f"Random Forest Accuracy     : {acc_rf:.2f}%")

print("\n✅ Medical Cost Prediction Completed Successfully!")
