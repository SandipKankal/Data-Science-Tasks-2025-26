# loan_prediction_improved.py
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier

# ---------------------------
# 1️⃣ Load Dataset
# ---------------------------
df = pd.read_csv("dataset/train.csv")
print("✅ Data Loaded Successfully!")
print(df.shape)
print(df.head())

# ---------------------------
# 2️⃣ Handle Missing Values
# ---------------------------
df.fillna({
    'Gender': df['Gender'].mode()[0],
    'Married': df['Married'].mode()[0],
    'Dependents': df['Dependents'].mode()[0],
    'Self_Employed': df['Self_Employed'].mode()[0],
    'LoanAmount': df['LoanAmount'].median(),
    'Loan_Amount_Term': df['Loan_Amount_Term'].mode()[0],
    'Credit_History': df['Credit_History'].mode()[0]
}, inplace=True)

# ---------------------------
# 3️⃣ Feature Engineering
# ---------------------------
# Convert categorical to numeric
cols = ['Gender', 'Married', 'Education', 'Self_Employed', 'Property_Area', 'Dependents', 'Loan_Status']
le = LabelEncoder()
for c in cols:
    df[c] = le.fit_transform(df[c])

# Add new features
df['Total_Income'] = df['ApplicantIncome'] + df['CoapplicantIncome']
df['LoanAmount_Log'] = np.log(df['LoanAmount'])
df['LoanAmount_Term_Years'] = df['Loan_Amount_Term'] / 12
df.drop(['Loan_ID', 'ApplicantIncome', 'CoapplicantIncome', 'LoanAmount', 'Loan_Amount_Term'], axis=1, inplace=True)

# ---------------------------
# 4️⃣ Define Features and Target
# ---------------------------
X = df.drop('Loan_Status', axis=1)
y = df['Loan_Status']

# Scale continuous columns
scaler = StandardScaler()
X[['Total_Income', 'LoanAmount_Log', 'LoanAmount_Term_Years']] = scaler.fit_transform(X[['Total_Income', 'LoanAmount_Log', 'LoanAmount_Term_Years']])

# ---------------------------
# 5️⃣ Split Dataset
# ---------------------------
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# ---------------------------
# 6️⃣ Logistic Regression (Tuned)
# ---------------------------
log_params = {
    'C': [0.01, 0.1, 1, 10],
    'solver': ['liblinear', 'lbfgs'],
    'penalty': ['l1', 'l2']
}
log_model = GridSearchCV(LogisticRegression(max_iter=500), log_params, cv=5, scoring='accuracy', n_jobs=-1)
log_model.fit(X_train, y_train)

y_pred_log = log_model.predict(X_test)

# ---------------------------
# 7️⃣ Decision Tree (Tuned)
# ---------------------------
tree_params = {
    'max_depth': [3, 4, 5, 6, 8, 10],
    'criterion': ['gini', 'entropy'],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}
tree_model = GridSearchCV(DecisionTreeClassifier(random_state=42), tree_params, cv=5, scoring='accuracy', n_jobs=-1)
tree_model.fit(X_train, y_train)

y_pred_tree = tree_model.predict(X_test)

# ---------------------------
# 8️⃣ Evaluation Function
# ---------------------------
def evaluate_model(name, y_true, y_pred):
    print(f"\n🔹 Model: {name}")
    print("Accuracy :", round(accuracy_score(y_true, y_pred), 3))
    print("Precision:", round(precision_score(y_true, y_pred), 3))
    print("Recall   :", round(recall_score(y_true, y_pred), 3))
    print("F1 Score :", round(f1_score(y_true, y_pred), 3))
    print("\nClassification Report:\n", classification_report(y_true, y_pred))
    
   # cm = confusion_matrix(y_true, y_pred)
   # sns.heatmap(cm, annot=True, fmt='d', cmap='Greens')
   # plt.title(f'{name} - Confusion Matrix')
   # plt.xlabel('Predicted')
   # plt.ylabel('Actual')
   # plt.show()

evaluate_model("Logistic Regression", y_test, y_pred_log)
evaluate_model("Decision Tree", y_test, y_pred_tree)

