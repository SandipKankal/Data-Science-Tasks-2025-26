import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# -------------------------
# Load dataset
# -------------------------
data = pd.read_csv("creditcard.csv")

# Split features and target
X = data.drop("Class", axis=1)
y = data["Class"]

# Scale data (important for Neural Network)
sc = StandardScaler()
X_scaled = sc.fit_transform(X)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# -------------------------
# Decision Tree Model
# -------------------------
tree_model = DecisionTreeClassifier(random_state=42)
tree_model.fit(X_train, y_train)
tree_pred = tree_model.predict(X_test)
tree_acc = accuracy_score(y_test, tree_pred)

# -------------------------
# Neural Network Model
# -------------------------
nn_model = MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=300, random_state=42)
nn_model.fit(X_train, y_train)
nn_pred = nn_model.predict(X_test)
nn_acc = accuracy_score(y_test, nn_pred)

# -------------------------
# Print Results
# -------------------------
print(f"Decision Tree Accuracy: {tree_acc:.2f}")
print(f"Neural Network Accuracy: {nn_acc:.2f}")
print("\nClassification Report (Neural Network):")
print(classification_report(y_test, nn_pred))

# -------------------------
# Visualization 1: Accuracy Comparison
# -------------------------
models = ['Decision Tree', 'Neural Network']
accuracies = [tree_acc, nn_acc]

plt.figure(figsize=(6,4))
plt.bar(models, accuracies, color=['skyblue', 'salmon'])
plt.ylim(0, 1)
plt.ylabel('Accuracy')
plt.title('Model Accuracy Comparison')
for i, v in enumerate(accuracies):
    plt.text(i, v + 0.02, f"{v:.2f}", ha='center', fontweight='bold')
plt.show()

# -------------------------
# Visualization 2: Confusion Matrix (Neural Network)
# -------------------------
cm = confusion_matrix(y_test, nn_pred)
plt.figure(figsize=(5,4))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix - Neural Network')
plt.show()

# -------------------------
# Visualization 3: Feature Importance (Decision Tree)
# -------------------------
feature_importances = tree_model.feature_importances_
features = X.columns
indices = np.argsort(feature_importances)[-10:]  # top 10 features

plt.figure(figsize=(8,5))
plt.barh(range(len(indices)), feature_importances[indices], color='lightgreen', align='center')
plt.yticks(range(len(indices)), [features[i] for i in indices])
plt.xlabel('Feature Importance')
plt.title('Top 10 Important Features - Decision Tree')
plt.show()

# -------------------------
# Visualization 4: Neural Network Loss Curve
# -------------------------
plt.figure(figsize=(6,4))
plt.plot(nn_model.loss_curve_)
plt.title('Neural Network Training Loss')
plt.xlabel('Iteration')
plt.ylabel('Loss')
plt.show()
