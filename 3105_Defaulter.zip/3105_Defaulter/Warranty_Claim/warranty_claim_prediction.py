# warranty_claim_prediction.py

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# -----------------------------
# 1. Sample dataset (you can replace this with your own CSV)
# -----------------------------
data = {
    'Region': ['North', 'South', 'East', 'West', 'North', 'South', 'East', 'West', 'North', 'East'],
    'Product_Category': ['Electronics', 'Furniture', 'Appliances', 'Electronics', 'Furniture', 'Electronics', 'Appliances', 'Furniture', 'Electronics', 'Appliances'],
    'Claim_Value': [2000, 5000, 1200, 2500, 7000, 4000, 900, 6000, 1500, 800],
    'Warranty_Period': [12, 24, 6, 18, 36, 12, 6, 24, 12, 6],
    'Customer_Age': [25, 45, 30, 35, 50, 40, 22, 55, 29, 31],
    'Genuine': ['Yes', 'No', 'Yes', 'Yes', 'No', 'Yes', 'No', 'No', 'Yes', 'Yes']
}

df = pd.DataFrame(data)

# -----------------------------
# 2. Data Preprocessing
# -----------------------------
print("Initial Data:\n", df.head(), "\n")

# Encode categorical columns
label_encoders = {}
for column in ['Region', 'Product_Category', 'Genuine']:
    le = LabelEncoder()
    df[column] = le.fit_transform(df[column])
    label_encoders[column] = le

# Feature-target split
X = df.drop('Genuine', axis=1)
y = df['Genuine']

# Scale numeric features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# -----------------------------
# 3. Train-Test Split
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.3, random_state=42)

# -----------------------------
# 4. Model Training
# -----------------------------
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# -----------------------------
# 5. Evaluation
# -----------------------------
y_pred = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))

# -----------------------------
# 6. Confusion Matrix
# -----------------------------
cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Greens')
plt.title("Confusion Matrix - Warranty Claim Authenticity")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()

# -----------------------------
# 7. Test on new data
# -----------------------------
new_claim = pd.DataFrame({
    'Region': ['South'],
    'Product_Category': ['Electronics'],
    'Claim_Value': [3500],
    'Warranty_Period': [12],
    'Customer_Age': [32]
})

# Encode new data
for col in ['Region', 'Product_Category']:
    new_claim[col] = label_encoders[col].transform(new_claim[col])

new_claim_scaled = scaler.transform(new_claim)

prediction = model.predict(new_claim_scaled)
result = label_encoders['Genuine'].inverse_transform(prediction)
print("\nPredicted authenticity for new claim:", result[0])
