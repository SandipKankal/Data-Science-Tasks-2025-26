Loan Prediction Model 🏦
This project uses machine learning to predict whether a loan application will be approved. It serves as an automated system to help a bank make faster, more consistent, and data-driven decisions, reducing potential human bias and manual effort.

📝 Project Overview
The model learns from historical data to identify patterns that lead to a loan being approved or rejected. The workflow is as follows:

Learn from the Past: The model is trained on a dataset of past loan applications, learning the relationship between applicant details (like income, credit history, etc.) and the final loan decision.

Find Patterns: It identifies key factors that are strong indicators of a successful application.

Make a Prediction: When given data for a new applicant, the model uses these learned patterns to predict whether the new loan should be approved or not.

Choose the Best Model: Two algorithms, Logistic Regression and a Decision Tree, were trained and compared. The Logistic Regression model was selected for its higher accuracy.

🤔 How the Winning Model (Logistic Regression) Works
The Logistic Regression model works like a judge, weighing evidence to make a final "yes" or "no" decision.

Assigns Importance (Weights): The model analyzes an applicant's details (features) and assigns a "weight" to each one based on its importance. For instance, Credit_History typically receives a very high weight.

Calculates a Probability Score: It combines these weighted features to produce a probability score between 0 and 1. This score represents the likelihood of the loan being approved. A score near 1 means approval is very likely, while a score near 0 means it's very unlikely. This calculation follows a characteristic S-shaped curve.

Makes the Final Decision: The model uses a 50% (0.5) probability threshold to classify the application:

If the score is above 0.5, the loan is predicted to be Approved.

If the score is below 0.5, the loan is predicted to be Rejected.

In essence, the model calculates the probability of success and makes a clear decision based on that probability.

📊 Dataset
This project uses the "Loan Predication" dataset from Kaggle.

Source: Kaggle Loan Predication Dataset

You must download the train_u6lujuX_CVtuZ9i.csv file and rename it to loan_data.csv in the project's root directory.

⚙️ Requirements
You need Python 3 and the following libraries:

pandas

NumPy

scikit-learn

Install them with this command:

Bash

pip install pandas numpy scikit-learn
🚀 How to Run
Make sure loan_data.csv and run_prediction.py are in the same folder.

Open your terminal and navigate to the project folder.

Run the script with the command:

Bash

python run_prediction.py
📈 Results
The final models performed as follows on the test data:

Model	Accuracy
Logistic Regression	86.18%
Decision Tree	72.36%

