# Step 1: Import all necessary libraries
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report
import warnings

# Ignore minor warnings to keep the output clean
warnings.filterwarnings('ignore')

print("--- Loan Prediction Model Execution Started ---")

# Step 2: Load the dataset
try:
    df = pd.read_csv('loan_data.csv')
    print("✅ Dataset loaded successfully.")
except FileNotFoundError:
    print("❌ Error: 'loan_data.csv' not found!")
    print("Please make sure the dataset is in the same folder as this script.")
    exit()

# Step 3: Data Cleaning and Preprocessing
print("⏳ Starting data cleaning and preprocessing...")

# Drop the Loan_ID column as it is not useful for prediction
df = df.drop('Loan_ID', axis=1)

# Fill missing values (imputation)
# For categorical columns, use the mode (most frequent value)
for col in ['Gender', 'Married', 'Dependents', 'Self_Employed', 'Credit_History']:
    df[col] = df[col].fillna(df[col].mode()[0])

# For numerical columns, use the mean
df['LoanAmount'] = df['LoanAmount'].fillna(df['LoanAmount'].mean())
df['Loan_Amount_Term'] = df['Loan_Amount_Term'].fillna(df['Loan_Amount_Term'].mean())

# Convert categorical features into numbers
# We use one-hot encoding for this
df = pd.get_dummies(df, columns=['Gender', 'Married', 'Dependents', 'Education', 'Self_Employed', 'Property_Area'], drop_first=True)

# Convert the target variable 'Loan_Status' to 0s and 1s
df['Loan_Status'] = df['Loan_Status'].map({'Y': 1, 'N': 0})

print("✅ Data preprocessing complete.")

# Step 4: Split data into features (X) and target (y)
X = df.drop('Loan_Status', axis=1)
y = df['Loan_Status']

# Split data into training and testing sets (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
print(f"✅ Data split into {len(X_train)} training samples and {len(X_test)} testing samples.")

# Step 5: Train the Machine Learning Models
print("⏳ Training Logistic Regression model...")
log_reg = LogisticRegression(max_iter=1000)
log_reg.fit(X_train, y_train)
print("✅ Logistic Regression model trained.")

print("⏳ Training Decision Tree model...")
dec_tree = DecisionTreeClassifier(random_state=42)
dec_tree.fit(X_train, y_train)
print("✅ Decision Tree model trained.")


# Step 6: Evaluate the Models
print("\n--- Model Evaluation ---")

# Predictions from Logistic Regression
log_reg_pred = log_reg.predict(X_test)
log_reg_accuracy = accuracy_score(y_test, log_reg_pred)
print(f"Logistic Regression Accuracy: {log_reg_accuracy:.4f}")
print("Classification Report:\n", classification_report(y_test, log_reg_pred))


# Predictions from Decision Tree
dec_tree_pred = dec_tree.predict(X_test)
dec_tree_accuracy = accuracy_score(y_test, dec_tree_pred)
print(f"Decision Tree Accuracy: {dec_tree_accuracy:.4f}")
print("Classification Report:\n", classification_report(y_test, dec_tree_pred))


# Step 7: Select and Announce the Best Model
print("\n--- Final Result ---")
if log_reg_accuracy > dec_tree_accuracy:
    print(f"🏆 Best Model: Logistic Regression with an accuracy of {log_reg_accuracy*100:.2f}%")
else:
    print(f"🏆 Best Model: Decision Tree with an accuracy of {dec_tree_accuracy*100:.2f}%")

print("\n--- Execution Finished ---")